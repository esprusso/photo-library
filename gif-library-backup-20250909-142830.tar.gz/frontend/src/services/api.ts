import axios from 'axios'
import { Image, Tag, Category, Job, ImageFilters, SortOptions, LibraryStats } from '../types'

const api = axios.create({
  baseURL: '/api',
  timeout: 10000, // Reduce timeout from 30s to 10s to fail faster
})

const API_DEBUG = (import.meta as any)?.env?.VITE_API_DEBUG === 'true'

// Add request interceptor for debugging
api.interceptors.request.use(
  (config) => {
    if (API_DEBUG) console.log(`API Request: ${config.method?.toUpperCase()} ${config.url}`)
    return config
  },
  (error) => {
    if (API_DEBUG) console.error('API Request Error:', error)
    return Promise.reject(error)
  }
)

// Add response interceptor for debugging
api.interceptors.response.use(
  (response) => {
    if (API_DEBUG) console.log(`API Response: ${response.config.method?.toUpperCase()} ${response.config.url} - ${response.status}`)
    return response
  },
  (error) => {
    if (API_DEBUG) {
      console.error(`API Error: ${error.config?.method?.toUpperCase()} ${error.config?.url}`)
      console.error('Error details:', error.message)
    }
    
    if (API_DEBUG) {
      if (error.code === 'ECONNABORTED') {
        console.error('Request timed out - backend may not be running or responding')
      } else if (error.response?.status === 404) {
        console.error('API endpoint not found')
      } else if (error.response?.status >= 500) {
        console.error('Server error - check backend logs')
      }
    }
    
    return Promise.reject(error)
  }
)

export const imageApi = {
  // Get images with filtering and pagination
  getImages: async (
    page: number = 1,
    pageSize: number = 50,
    filters: ImageFilters = {},
    sort: SortOptions = { sort_by: 'created_at', sort_order: 'desc' }
  ): Promise<Image[]> => {
    const params = new URLSearchParams({
      page: page.toString(),
      page_size: pageSize.toString(),
      sort_by: sort.sort_by,
      sort_order: sort.sort_order,
    })

    // Add filters
    if (filters.query) params.append('query', filters.query)
    if (filters.tags?.length) params.append('tags', filters.tags.join(','))
    if (filters.categories?.length) params.append('categories', filters.categories.join(','))
    if (filters.favorite !== undefined) params.append('favorite', filters.favorite.toString())
    if (filters.rating !== undefined) params.append('rating', filters.rating.toString())
    if (filters.model_name) params.append('model_name', filters.model_name)
    if (filters.file_format) params.append('file_format', filters.file_format)
    if (filters.exclude_jpg !== undefined) params.append('exclude_jpg', filters.exclude_jpg.toString())
    if (filters.exclude_static !== undefined) params.append('exclude_static', filters.exclude_static.toString())
    if (filters.media) params.append('media', filters.media)

    const { data } = await api.get(`/images/?${params}`)
    return data
  },
  // Delete image (optionally original)
  deleteImage: async (id: number, deleteOriginal: boolean = false): Promise<{ message: string }> => {
    const { data } = await api.delete(`/images/${id}?delete_original=${deleteOriginal}`)
    return data
  },
  // Get a random image, optional media filter ('gif' | 'video' | 'image') and unrated filter
  getRandom: async (media?: 'gif' | 'video' | 'image', unrated?: boolean): Promise<Image> => {
    const params = new URLSearchParams()
    if (media) params.append('media', media)
    if (unrated) params.append('unrated', 'true')
    const url = params.toString() ? `/images/random?${params}` : '/images/random'
    const { data } = await api.get(url)
    return data
  },

  // Get single image
  getImage: async (id: number): Promise<Image> => {
    const { data } = await api.get(`/images/${id}`)
    return data
  },

  // Toggle favorite
  toggleFavorite: async (id: number): Promise<{ id: number; favorite: boolean }> => {
    const { data } = await api.post(`/images/${id}/favorite`)
    return data
  },

  // Set rating
  setRating: async (id: number, rating: number): Promise<{ id: number; rating: number }> => {
    const { data } = await api.post(`/images/${id}/rating?rating=${rating}`)
    return data
  },

  // Add tags to image
  addTags: async (id: number, tagNames: string[]): Promise<{ message: string }> => {
    const { data } = await api.post(`/images/${id}/tags`, tagNames)
    return data
  },

  // Remove tags from image
  removeTags: async (id: number, tagNames: string[]): Promise<{ message: string }> => {
    const { data } = await api.delete(`/images/${id}/tags`, { data: tagNames })
    return data
  },

  // Download images
  downloadImages: async (imageIds: number[]): Promise<{ download_url: string }> => {
    const { data } = await api.post('/images/download', imageIds)
    return data
  },

  // Get search suggestions
  getSearchSuggestions: async (query: string, limit: number = 10): Promise<Array<{
    type: string
    value: string
    label: string
  }>> => {
    const { data } = await api.get(`/images/search/suggestions?query=${encodeURIComponent(query)}&limit=${limit}`)
    return data
  },

  // Upload an image file
  uploadImage: async (formData: FormData): Promise<{ id: number; filename: string }> => {
    // Do not set Content-Type manually; let the browser add proper multipart boundaries
    const { data } = await api.post('/images/upload', formData)
    return data
  }
}

export const tagApi = {
  // Get all tags
  getTags: async (search?: string, sortBy: string = 'name'): Promise<Tag[]> => {
    const params = new URLSearchParams({ sort_by: sortBy })
    if (search) params.append('search', search)
    
    const { data } = await api.get(`/tags/?${params}`)
    return data
  },

  // Create tag
  createTag: async (name: string, color?: string): Promise<Tag> => {
    const { data } = await api.post('/tags/', { name, color })
    return data
  },

  // Update tag
  updateTag: async (id: number, updates: { name?: string; color?: string }): Promise<Tag> => {
    const { data } = await api.put(`/tags/${id}`, updates)
    return data
  },

  // Delete tag
  deleteTag: async (id: number): Promise<{ message: string }> => {
    const { data } = await api.delete(`/tags/${id}`)
    return data
  },
  
  // AI Auto-tagging methods
  autoTagSingle: async (imageId: number): Promise<{ message: string; tags: string[]; all_suggested_tags: string[] }> => {
    const { data } = await api.post('/tags/auto-tag-single', { image_id: imageId })
    return data
  },
  
  autoTagBatch: async (imageIds: number[]): Promise<{ message: string; image_count: number; status: string }> => {
    const { data } = await api.post('/tags/auto-tag-batch', { image_ids: imageIds })
    return data
  },
  
  autoTagAllUntagged: async (): Promise<{ message: string; image_count: number; status: string }> => {
    const { data } = await api.post('/tags/auto-tag-all-untagged')
    return data
  },

  // Bulk create tags
  bulkCreateTags: async (tagNames: string[]): Promise<{ message: string; created: number }> => {
    const { data } = await api.post('/tags/bulk-create', tagNames)
    return data
  }
}

export const categoryApi = {
  // Get all categories
  getCategories: async (search?: string, sortBy: string = 'name', media?: 'image' | 'video'): Promise<Category[]> => {
    const params = new URLSearchParams({ sort_by: sortBy })
    if (search) params.append('search', search)
    if (media) params.append('media', media)
    
    const { data } = await api.get(`/categories/?${params}`)
    return data
  },

  // Create category (color deprecated; supports optional cover_image_id)
  createCategory: async (name: string, description?: string, color?: string, cover_image_id?: number): Promise<Category> => {
    const payload: any = { name, description }
    if (color) payload.color = color
    if (cover_image_id !== undefined) payload.cover_image_id = cover_image_id
    const { data } = await api.post('/categories/', payload)
    return data
  },

  // Update category
  updateCategory: async (id: number, updates: { name?: string; description?: string; color?: string; cover_image_id?: number | null }): Promise<Category> => {
    const { data } = await api.put(`/categories/${id}`, updates)
    return data
  },

  // Delete category
  deleteCategory: async (id: number): Promise<{ message: string }> => {
    const { data } = await api.delete(`/categories/${id}`)
    return data
  },
  // Bulk delete categories
  bulkDeleteCategories: async (categoryIds: number[]): Promise<{ message: string }> => {
    const { data } = await api.post('/categories/bulk-delete', { 
      category_ids: categoryIds 
    })
    return data
  },

  // Add images to category
  addImagesToCategory: async (categoryId: number, imageIds: number[]): Promise<{ message: string }> => {
    const { data } = await api.post(`/categories/${categoryId}/images`, imageIds)
    return data
  },

  // Set/clear category cover
  setCover: async (categoryId: number, imageId: number): Promise<{ message: string; cover_image_id: number; cover_image_url: string }> => {
    const { data } = await api.post(`/categories/${categoryId}/cover/${imageId}`)
    return data
  },
  clearCover: async (categoryId: number): Promise<{ message: string }> => {
    const { data } = await api.delete(`/categories/${categoryId}/cover`)
    return data
  },

  // Remove images from category
  removeImagesFromCategory: async (categoryId: number, imageIds: number[]): Promise<{ message: string }> => {
    const { data } = await api.delete(`/categories/${categoryId}/images`, { data: imageIds })
    return data
  },

  // Auto-categorize based on folder structure
  autoCategorizeByFolders: async (): Promise<{ job_id: number; message: string }> => {
    const { data } = await api.post('/categories/auto-categorize-folders')
    return data
  },

  // Cleanup RAW files from database
  cleanupRawFiles: async (): Promise<{ message: string; removed_files: string; removed_count: number }> => {
    const { data } = await api.post('/categories/cleanup-raw-files')
    return data
  },

  // Cleanup categories with few images
  cleanupEmptyCategories: async (minImages: number = 1): Promise<{ message: string; deleted_categories: string; deleted_count: number }> => {
    const { data } = await api.post(`/categories/cleanup-empty?min_images=${minImages}`)
    return data
  }
}

export const jobApi = {
  // Get jobs
  getJobs: async (type?: string, status?: string, limit: number = 50): Promise<Job[]> => {
    const params = new URLSearchParams({ limit: limit.toString() })
    if (type) params.append('job_type', type)
    if (status) params.append('status', status)
    
    const { data } = await api.get(`/jobs/?${params}`)
    return data
  },

  // Get single job
  getJob: async (id: number): Promise<Job> => {
    const { data } = await api.get(`/jobs/${id}`)
    return data
  },

  // Start indexing job
  startIndexing: async (): Promise<{ message: string; job_id: number }> => {
    const { data } = await api.post('/jobs/indexing')
    return data
  },
  // Start indexing clips job
  startIndexingClips: async (): Promise<{ message: string; job_id: number }> => {
    const { data } = await api.post('/jobs/indexing-clips')
    return data
  },

  // Start thumbnail job
  startThumbnails: async (forceRegenerate: boolean = false): Promise<{ message: string; job_id: number }> => {
    const { data } = await api.post('/jobs/thumbnails', { force_regenerate: forceRegenerate })
    return data
  },
  startClipThumbnails: async (forceRegenerate: boolean = false): Promise<{ message: string; job_id: number }> => {
    const { data } = await api.post('/jobs/thumbnails', { force_regenerate: forceRegenerate, only_videos: true })
    return data
  },

  // Start tagging job
  startTagging: async (imageIds?: number[]): Promise<{ message: string; job_id: number }> => {
    const { data } = await api.post('/jobs/tagging', { image_ids: imageIds })
    return data
  },

  // Cancel job
  cancelJob: async (id: number): Promise<{ message: string }> => {
    const { data } = await api.delete(`/jobs/${id}`)
    return data
  },

  // Force-kill stalled jobs
  forceKillStalled: async (): Promise<{ message: string; killed_jobs: any[] }> => {
    const { data } = await api.post('/jobs/force-kill-stalled')
    return data
  }
}

export const libraryApi = {
  // Get library stats
  getStats: async (): Promise<LibraryStats> => {
    const { data } = await api.get('/stats')
    return data
  },

  // Trigger library scan
  scanLibrary: async (): Promise<{ message: string }> => {
    const { data } = await api.post('/scan')
    return data
  },

  // Get health status
  getHealth: async (): Promise<{ status: string }> => {
    const { data } = await api.get('/health')
    return data
  },

  // Test API connectivity (fast endpoint for debugging)
  testConnection: async (): Promise<{ message: string; version: string }> => {
    const { data } = await api.get('/health')
    return data
  }
}

export const duplicateApi = {
  // Find duplicate groups (default GIFs)
  getDuplicates: async (media: 'gif' | 'video' | 'image' = 'gif'): Promise<Array<{ key: string, count: number, items: { id: number, filename: string, file_size?: number, thumbnail_path: string, width?: number, height?: number, created_at?: string }[] }>> => {
    const { data } = await api.get(`/images/duplicates?media=${media}`)
    return data
  },
  // Merge duplicates: keep one, remove others
  merge: async (keepId: number, removeIds: number[], deleteOriginals: boolean = false): Promise<{ message: string }> => {
    const { data } = await api.post('/images/duplicates/merge', { keep_id: keepId, remove_ids: removeIds, delete_originals: deleteOriginals })
    return data
  }
}

export default api
