import os
import hashlib
import re
from datetime import datetime
from typing import List, Set, Optional
from sqlalchemy.orm import Session
from sqlalchemy import func

from backend.models import Image, Job, Category
from sqlalchemy import text
from backend.services.metadata_extractor import MetadataExtractor
from backend.services.thumbnail_generator import ThumbnailGenerator
from backend.services.media_manager import MediaManager


class ImageScanner:
    """Scan directories for images and update the database"""
    
    def __init__(self):
        self.metadata_extractor = MetadataExtractor()
        self.thumbnail_generator = ThumbnailGenerator()
        self.media_manager = MediaManager()
        self.supported_extensions = {'.png', '.jpg', '.jpeg', '.webp', '.tiff', '.bmp', '.gif', '.mp4', '.webm', '.mov', '.avi'}
        # Patterns to exclude from scanning (Synology NAS thumbnails, etc.)
        self.exclude_patterns = {
            '@eaDir',           # Synology metadata directory
            'SYNOFILE_THUMB',   # Synology thumbnail files
            '.DS_Store',        # macOS metadata
            'Thumbs.db',        # Windows thumbnails
            '.thumbnails',      # Linux thumbnails
            '@tmp',             # Synology temp directory
        }
    
    def scan_library(self, db: Session, job_id: Optional[int] = None, library_paths: Optional[List[str]] = None, media_filter: Optional[str] = None):
        """Scan library paths for media.
        - library_paths: scan only these paths (defaults to LIBRARY_PATHS)
        - media_filter: 'image' or 'video' to restrict extensions
        """
        library_paths = library_paths or self._get_library_paths()
        
        if job_id:
            job = db.query(Job).filter(Job.id == job_id).first()
            if job:
                job.status = 'running'
                job.started_at = datetime.now()
                db.commit()
        
        try:
            all_image_paths = []
            
            # Collect all media files
            for library_path in library_paths:
                if os.path.exists(library_path):
                    image_paths = self._scan_directory(library_path, media_filter=media_filter)
                    all_image_paths.extend(image_paths)
            
            if job_id:
                job.total_items = len(all_image_paths)
                db.commit()
            
            # Process each image
            processed_count = 0
            added_count = 0
            updated_count = 0
            
            for image_path in all_image_paths:
                try:
                    result = self._process_image(db, image_path)
                    if result == 'added':
                        added_count += 1
                    elif result == 'updated':
                        updated_count += 1
                    
                    processed_count += 1
                    
                    if job_id and processed_count % 10 == 0:
                        # Update progress every 10 items
                        job.processed_items = processed_count
                        job.progress = int((processed_count / len(all_image_paths)) * 100)
                        db.commit()
                
                except Exception as e:
                    import logging
                    logging.error(f"Error processing {image_path}: {e}")
                    # Ensure broken transactions don't poison subsequent queries
                    try:
                        db.rollback()
                    except Exception:
                        pass
                    continue
            
            # Clean up orphaned records
            orphaned_count = self._cleanup_orphaned_images(db)
            
            if job_id:
                job.status = 'completed'
                job.completed_at = datetime.now()
                job.processed_items = processed_count
                job.progress = 100
                job.result = {
                    'processed': processed_count,
                    'added': added_count,
                    'updated': updated_count,
                    'orphaned_removed': orphaned_count
                }
                db.commit()
                
        except Exception as e:
            if job_id:
                job.status = 'failed'
                job.error_message = str(e)
                db.commit()
            raise e
    
    def _get_library_paths(self) -> List[str]:
        """Get configured library paths from environment"""
        library_paths_str = os.getenv('LIBRARY_PATHS', '/library')
        return [path.strip() for path in library_paths_str.split(',')]
    
    def _scan_directory(self, directory: str, media_filter: Optional[str] = None) -> List[str]:
        """Recursively scan directory for media files (optionally filtered to images or videos)"""
        image_paths = []
        video_exts = {'.mp4', '.webm', '.mov', '.avi', '.m4v'}
        if media_filter == 'video':
            allowed_exts = video_exts
        elif media_filter == 'image':
            allowed_exts = {e for e in self.supported_extensions if e not in video_exts}
        else:
            allowed_exts = self.supported_extensions
        
        for root, dirs, files in os.walk(directory):
            # Skip excluded directories
            dirs[:] = [d for d in dirs if not any(pattern in d for pattern in self.exclude_patterns)]
            
            # Skip if current path contains excluded patterns
            if any(pattern in root for pattern in self.exclude_patterns):
                continue
                
            for file in files:
                # Skip excluded files
                if any(pattern in file for pattern in self.exclude_patterns):
                    continue
                    
                file_path = os.path.join(root, file)
                file_ext = os.path.splitext(file)[1].lower()
                
                if file_ext in allowed_exts:
                    image_paths.append(file_path)
        
        return image_paths
    
    def _process_image(self, db: Session, image_path: str) -> str:
        """Process a single image file"""
        # Check if image already exists in database
        existing_image = db.query(Image).filter(Image.path == image_path).first()
        
        # Get file stats
        try:
            stat = os.stat(image_path)
            file_mtime = datetime.fromtimestamp(stat.st_mtime)
        except OSError:
            return 'error'
        
        # If image exists and hasn't been modified, skip
        if existing_image and existing_image.modified_at and existing_image.modified_at >= file_mtime:
            return 'skipped'
        
        # Extract metadata
        metadata = self.metadata_extractor.extract_metadata(image_path)
        
        if existing_image:
            # Update existing image
            self._update_image_from_metadata(existing_image, image_path, metadata)
            # Auto-categorize based on folder structure
            self._assign_folder_categories(db, existing_image, image_path)
            # Ensure local media copy exists
            self.media_manager.update_image_local_path(db, existing_image)
            db.commit()
            # Generate thumbnail for updated image
            self.thumbnail_generator.generate_single_thumbnail(existing_image)
            return 'updated'
        else:
            # Create new image record
            image = self._create_image_from_metadata(image_path, metadata)
            db.add(image)
            db.flush()  # Get the ID
            # Auto-categorize based on folder structure
            self._assign_folder_categories(db, image, image_path)
            # Create local media copy
            self.media_manager.update_image_local_path(db, image)
            db.commit()
            # Generate thumbnail for new image
            self.thumbnail_generator.generate_single_thumbnail(image)
            return 'added'
    
    def _create_image_from_metadata(self, image_path: str, metadata: dict) -> Image:
        """Create a new Image record from metadata"""
        file_info = metadata.get('file_info', {})
        image_info = metadata.get('image_info', {})
        normalized = metadata.get('normalized', {})
        
        return Image(
            path=image_path,
            filename=os.path.basename(image_path),
            file_size=file_info.get('size'),
            width=image_info.get('width'),
            height=image_info.get('height'),
            aspect_ratio=image_info.get('aspect_ratio'),
            format=image_info.get('format'),
            
            # AI metadata
            prompt=normalized.get('prompt'),
            negative_prompt=normalized.get('negative_prompt'),
            model_name=normalized.get('model_name'),
            model_hash=normalized.get('model_hash'),
            seed=str(normalized.get('seed')) if normalized.get('seed') else None,
            steps=normalized.get('steps'),
            cfg_scale=normalized.get('cfg_scale'),
            sampler=normalized.get('sampler'),
            
            # Timestamps
            created_at=file_info.get('created', datetime.now()),
            modified_at=file_info.get('modified', datetime.now()),
            indexed_at=datetime.now()
        )
    
    def _update_image_from_metadata(self, image: Image, image_path: str, metadata: dict):
        """Update existing Image record from metadata"""
        file_info = metadata.get('file_info', {})
        image_info = metadata.get('image_info', {})
        normalized = metadata.get('normalized', {})
        
        # Update basic file info
        image.filename = os.path.basename(image_path)
        image.file_size = file_info.get('size')
        image.width = image_info.get('width')
        image.height = image_info.get('height')
        image.aspect_ratio = image_info.get('aspect_ratio')
        image.format = image_info.get('format')
        
        # Update AI metadata
        image.prompt = normalized.get('prompt')
        image.negative_prompt = normalized.get('negative_prompt')
        image.model_name = normalized.get('model_name')
        image.model_hash = normalized.get('model_hash')
        image.seed = str(normalized.get('seed')) if normalized.get('seed') else None
        image.steps = normalized.get('steps')
        image.cfg_scale = normalized.get('cfg_scale')
        image.sampler = normalized.get('sampler')
        
        # Update timestamps
        image.modified_at = file_info.get('modified', datetime.now())
        image.indexed_at = datetime.now()
    
    def _extract_folder_categories(self, image_path: str) -> List[str]:
        """Extract category names from folder structure"""
        # Get library paths to determine relative path
        library_paths = self._get_library_paths()

        # Normalize known host paths to container mount points
        # This allows categorization to work even if DB stored host paths
        host_gif = '/volume1/homes/rheritage/Spicy Gif Library'
        host_clip = '/volume1/homes/rheritage/Spicy Clip Library'
        if image_path.startswith(host_gif):
            image_path = image_path.replace(host_gif, '/library', 1)
        elif image_path.startswith(host_clip):
            image_path = image_path.replace(host_clip, '/clips', 1)
        
        # Find which library path this image belongs to
        relative_path = None
        for lib_path in library_paths:
            if image_path.startswith(lib_path):
                relative_path = os.path.relpath(image_path, lib_path)
                break
        
        if not relative_path or relative_path == os.path.basename(image_path):
            # Image is at root level, no folder categories
            return []
        
        # Extract folder names from path (excluding filename)
        folder_path = os.path.dirname(relative_path)
        if not folder_path or folder_path == '.':
            return []
        
        # Split path and clean up folder names
        folder_parts = folder_path.split(os.sep)
        categories = []
        
        for part in folder_parts:
            if part and part != '.':
                # Clean up folder name for category
                category_name = part.replace('_', ' ').replace('-', ' ').title()
                # Remove numbers and special chars if they're just organizational
                # Keep meaningful names, remove pure numbers or dates
                if not re.match(r'^\d+$', category_name) and not re.match(r'^\d{4}-\d{2}-\d{2}$', category_name):
                    categories.append(category_name)
        
        return categories
    
    def _assign_folder_categories(self, db: Session, image: Image, image_path: str):
        """Assign categories to image based on folder structure"""
        category_names = self._extract_folder_categories(image_path)
        
        if not category_names:
            return
        
        # Determine media type of this item
        ext = os.path.splitext(image.filename)[1].lower() if image.filename else ''
        video_exts = {'.mp4', '.webm', '.mov', '.avi', '.m4v'}
        media_type = 'video' if ext in video_exts else 'image'

        # Create categories if they don't exist and assign to image
        for category_name in category_names:
            category_id = None
            # When media_type column may be missing, differentiate video categories
            # by renaming them with a suffix to avoid name collisions with GIF categories
            name_fallback = category_name + " (Clips)" if media_type == 'video' else category_name
            # Preferred path: ORM with media_type
            try:
                category = db.query(Category).filter(Category.name == category_name, Category.media_type == media_type).first()
                if not category:
                    colors = ["#EF4444", "#F59E0B", "#10B981", "#3B82F6", "#8B5CF6", "#EC4899", "#F97316", "#84CC16"]
                    color = colors[hash(category_name) % len(colors)]
                    category = Category(name=category_name, description=f"Auto-generated from folder: {category_name}", color=color, media_type=media_type)
                    db.add(category)
                    db.flush()
                category_id = category.id
            except Exception:
                # Fallback path during migration: raw SQL upsert by name only
                try:
                    db.rollback()
                    upsert_sql = text("""
                        INSERT INTO categories (name, description)
                        VALUES (:name, :desc)
                        ON CONFLICT (name) DO NOTHING
                        RETURNING id
                    """)
                    # For videos, use suffixed name to differentiate when media_type is unavailable
                    sel_name = name_fallback
                    res = db.execute(upsert_sql, {"name": sel_name, "desc": f"Auto-generated from folder: {category_name}"})
                    row = res.fetchone()
                    if row and row[0]:
                        category_id = row[0]
                    else:
                        sel = db.execute(text("SELECT id FROM categories WHERE name = :name"), {"name": sel_name}).fetchone()
                        category_id = sel[0] if sel else None
                except Exception:
                    db.rollback()
                    category_id = None

            # Assign via association table directly to avoid touching ORM relationship
            if category_id:
                try:
                    db.execute(text("""
                        INSERT INTO image_categories (image_id, category_id)
                        VALUES (:iid, :cid)
                        ON CONFLICT DO NOTHING
                    """), {"iid": image.id, "cid": category_id})
                    db.commit()
                except Exception:
                    db.rollback()
    
    def _cleanup_orphaned_images(self, db: Session) -> int:
        """Remove database records for images that no longer exist on disk"""
        # Ensure we're not in a failed transaction state
        try:
            db.rollback()
        except Exception:
            pass
        images = db.query(Image).all()
        orphaned_count = 0
        
        for image in images:
            if not os.path.exists(image.path):
                db.delete(image)
                orphaned_count += 1
        
        if orphaned_count > 0:
            db.commit()
        
        return orphaned_count
    
    def get_scan_stats(self, db: Session) -> dict:
        """Get statistics about the current library"""
        total_images = db.query(Image).count()
        
        # Get counts by format
        format_stats = db.query(
            Image.format, 
            func.count(Image.id).label('count')
        ).group_by(Image.format).all()
        
        # Get counts by model
        model_stats = db.query(
            Image.model_name, 
            func.count(Image.id).label('count')
        ).filter(Image.model_name.isnot(None)).group_by(Image.model_name).all()
        
        return {
            'total_images': total_images,
            'formats': {stat[0]: stat[1] for stat in format_stats if stat[0]},
            'models': {stat[0]: stat[1] for stat in model_stats[:10]}  # Top 10
        }
